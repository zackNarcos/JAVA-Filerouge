-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : sam. 27 nov. 2021 à 23:01
-- Version du serveur :  5.7.34
-- Version de PHP : 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `java_file_rouge`
--

-- --------------------------------------------------------

--
-- Structure de la table `antecedant`
--

CREATE TABLE `antecedant` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `antecedant`
--

INSERT INTO `antecedant` (`id`) VALUES
(1),
(2),
(3),
(4),
(5);

-- --------------------------------------------------------

--
-- Structure de la table `consultation`
--

CREATE TABLE `consultation` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `temperature` int(2) NOT NULL,
  `tension` int(3) NOT NULL,
  `poids` int(2) NOT NULL,
  `id_patient` int(11) NOT NULL,
  `id_prestations` int(11) NOT NULL,
  `id_medecin` int(11) NOT NULL,
  `id_ordonance` int(11) NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `consultation`
--

INSERT INTO `consultation` (`id`, `date`, `temperature`, `tension`, `poids`, `id_patient`, `id_prestations`, `id_medecin`, `id_ordonance`, `status`) VALUES
(1, '2021-11-18', 28, 102, 90, 18, 1, 1, 1, 'ANNULER');

-- --------------------------------------------------------

--
-- Structure de la table `detail_antecedant`
--

CREATE TABLE `detail_antecedant` (
  `id` int(11) NOT NULL,
  `maladie` varchar(255) NOT NULL,
  `id_antecedant` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `detail_ordonnace`
--

CREATE TABLE `detail_ordonnace` (
  `id` int(11) NOT NULL,
  `posologie` varchar(15) NOT NULL,
  `duree` int(11) NOT NULL,
  `medicament` varchar(20) NOT NULL,
  `id_ordonnance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `detail_ordonnace`
--

INSERT INTO `detail_ordonnace` (`id`, `posologie`, `duree`, `medicament`, `id_ordonnance`) VALUES
(1, 'm m s', 3, 'efferalgan', 1),
(2, 'm s', 4, 'ibuprofene', 1);

-- --------------------------------------------------------

--
-- Structure de la table `detail_prestation`
--

CREATE TABLE `detail_prestation` (
  `id` int(11) NOT NULL,
  `id_responsable` int(11) NOT NULL,
  `id_prestation` int(11) NOT NULL,
  `id_patient` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `detail_prestation`
--

INSERT INTO `detail_prestation` (`id`, `id_responsable`, `id_prestation`, `id_patient`, `date`, `status`) VALUES
(1, 18, 1, 18, '2021-11-05', 'ANNULE'),
(2, 18, 1, 18, '2021-11-27', 'CONFIRME');

-- --------------------------------------------------------

--
-- Structure de la table `detail_specialisation`
--

CREATE TABLE `detail_specialisation` (
  `id` int(11) NOT NULL,
  `id_specialisation` int(11) NOT NULL,
  `id_medecin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `detail_specialisation`
--

INSERT INTO `detail_specialisation` (`id`, `id_specialisation`, `id_medecin`) VALUES
(1, 2, 18),
(8, 3, 1),
(10, 8, 22),
(11, 8, 23),
(12, 8, 24),
(14, 2, 1),
(16, 15, 26),
(19, 2, 30);

-- --------------------------------------------------------

--
-- Structure de la table `medecin`
--

CREATE TABLE `medecin` (
  `id` int(11) NOT NULL,
  `id_secretaire` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `medecin`
--

INSERT INTO `medecin` (`id`, `id_secretaire`) VALUES
(1, 1),
(24, 1),
(25, 1),
(26, 1),
(29, 1),
(30, 1),
(0, 1),
(0, 1),
(0, 1),
(0, 1),
(0, 1),
(0, 1),
(0, 1),
(31, 1),
(32, 1),
(33, 1);

-- --------------------------------------------------------

--
-- Structure de la table `ordonnance`
--

CREATE TABLE `ordonnance` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `ordonnance`
--

INSERT INTO `ordonnance` (`id`) VALUES
(1);

-- --------------------------------------------------------

--
-- Structure de la table `patient`
--

CREATE TABLE `patient` (
  `id` int(11) NOT NULL,
  `code` int(11) NOT NULL,
  `id_antecedants` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `patient`
--

INSERT INTO `patient` (`id`, `code`, `id_antecedants`) VALUES
(0, 1234, 1),
(0, 1235, 0),
(0, 1235, 2),
(0, 1235, 3),
(0, 1235, 4),
(18, 1235, 5);

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

CREATE TABLE `prestation` (
  `id` int(11) NOT NULL,
  `libelle` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `prestation`
--

INSERT INTO `prestation` (`id`, `libelle`) VALUES
(1, 'RADIOLOGIE'),
(2, 'ECHOGRAPHIE');

-- --------------------------------------------------------

--
-- Structure de la table `rendez_vous`
--

CREATE TABLE `rendez_vous` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `id_patient` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `typeSpecialisation` varchar(50) DEFAULT NULL,
  `typeRdv` varchar(50) NOT NULL,
  `typePrestation` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `rendez_vous`
--

INSERT INTO `rendez_vous` (`id`, `date`, `id_patient`, `status`, `typeSpecialisation`, `typeRdv`, `typePrestation`) VALUES
(1, '2021-11-16', 18, 'ANNULER', '', '', ''),
(2, '2021-11-24', 0, 'ANNULER', '', '', ''),
(3, '2021-11-26', 18, 'ANNULER', '', '', ''),
(4, '2021-11-12', 18, 'ANNULER', '', '', ''),
(5, '2021-11-17', 18, 'ANNULER', '', '', ''),
(6, '2021-11-17', 18, 'ATTENTE', 'GENERALISTE', '', ''),
(7, '2021-11-17', 18, 'ATTENTE', 'OPHTALMOLOGUE', '', ''),
(8, '2021-11-17', 18, 'ATTENTE', 'GENERALISTE', '', ''),
(9, '2021-11-17', 18, 'ATTENTE', 'DENTISTE', '', ''),
(10, '2021-11-17', 18, 'ATTENTE', 'GENERALISTE', '', ''),
(11, '2021-11-17', 18, 'ATTENTE', 'DENTISTE', 'Consultation', NULL),
(12, '2021-11-17', 18, 'ATTENTE', NULL, 'Prestation', 'RADIOLOGIE'),
(13, '2021-11-18', 18, 'ANNULER', 'DENTISTE', 'Consultation', NULL),
(14, '2021-11-18', 18, 'ATTENTE', NULL, 'Prestation', 'RADIOLOGIE');

-- --------------------------------------------------------

--
-- Structure de la table `responsable_prestation`
--

CREATE TABLE `responsable_prestation` (
  `id` int(11) NOT NULL,
  `libelle` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `responsable_prestation`
--

INSERT INTO `responsable_prestation` (`id`, `libelle`) VALUES
(18, 'echographie');

-- --------------------------------------------------------

--
-- Structure de la table `secretaire`
--

CREATE TABLE `secretaire` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `secretaire`
--

INSERT INTO `secretaire` (`id`) VALUES
(1);

-- --------------------------------------------------------

--
-- Structure de la table `specialisation`
--

CREATE TABLE `specialisation` (
  `id` int(11) NOT NULL,
  `libelle` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `specialisation`
--

INSERT INTO `specialisation` (`id`, `libelle`) VALUES
(2, 'DENTISTE'),
(3, 'OPHTALMOLOGUE');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `nom`, `prenom`, `role`, `login`, `password`) VALUES
(1, 'zack', 'secrétaire', 'ROLE_SECRETAIRE', ' secretaire', '  secretaire'),
(18, 'ABESSOLO 2', 'Zacharie', 'ROLE_PATIENT', 'passer', 'passer'),
(20, 'ok', 'ok', 'ROLE_PATIENT', 'ok', 'ok'),
(21, 'root', 'root', 'ROOT', 'root', 'root'),
(22, 'zack', 'secrétaire', 'ROLE_PATIENT', ' secretaire', '  secretaire'),
(23, 'zack', 'secrétaire', 'ROLE_PATIENT', ' secretaire', '  secretaire'),
(24, 'zack', 'secrétaire', 'ROLE_PATIENT', ' secretaire', '  secretaire'),
(25, 'medecin', 'medecin', 'ROLE_PATIENT', 'medecin', 'medecin'),
(26, 'medecin', 'medecin', 'ROLE_PATIENT', 'medecin', 'medecin'),
(27, 'cacy', 'baby', 'ROLE_SECRETAIRE', 'sec', 'sec'),
(28, 'Anaurel', 'trop canon', 'ROLE_RESPONSABLE', 'tropbelle', '1234'),
(29, 'medecin', 'medecin', 'ROLE_PATIENT', 'medecin', 'medecin'),
(30, 'Karess', 'Ndong', 'ROLE_PATIENT', 'karess@gmail.com', 'passer'),
(31, 'Karess', 'Ndong', 'ROLE_MEDECIN', 'karess@gmail.com', 'passer'),
(32, 'yves', 'Ndong', 'ROLE_MEDECIN', 'karess@gmail.com', 'passer'),
(33, 'yves', 'Ndong', 'ROLE_MEDECIN', '', 'passer');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `antecedant`
--
ALTER TABLE `antecedant`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `consultation`
--
ALTER TABLE `consultation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_patient` (`id_patient`),
  ADD KEY `id_prestation` (`id_prestations`),
  ADD KEY `id_medecin` (`id_medecin`),
  ADD KEY `id_ordonance` (`id_ordonance`);

--
-- Index pour la table `detail_antecedant`
--
ALTER TABLE `detail_antecedant`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_anteccedant` (`id_antecedant`);

--
-- Index pour la table `detail_ordonnace`
--
ALTER TABLE `detail_ordonnace`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_medicament` (`medicament`),
  ADD KEY `id_ordonnance` (`id_ordonnance`);

--
-- Index pour la table `detail_prestation`
--
ALTER TABLE `detail_prestation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_responsable` (`id_responsable`),
  ADD KEY `id_prestation` (`id_prestation`),
  ADD KEY `id_patient` (`id_patient`);

--
-- Index pour la table `detail_specialisation`
--
ALTER TABLE `detail_specialisation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_specialisation` (`id_specialisation`),
  ADD KEY `id_medecin` (`id_medecin`);

--
-- Index pour la table `medecin`
--
ALTER TABLE `medecin`
  ADD KEY `id_secretaire` (`id_secretaire`),
  ADD KEY `id_user` (`id`);

--
-- Index pour la table `ordonnance`
--
ALTER TABLE `ordonnance`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `patient`
--
ALTER TABLE `patient`
  ADD KEY `id_antecedants` (`id_antecedants`),
  ADD KEY `id` (`id`);

--
-- Index pour la table `prestation`
--
ALTER TABLE `prestation`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `rendez_vous`
--
ALTER TABLE `rendez_vous`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_patient` (`id_patient`);

--
-- Index pour la table `responsable_prestation`
--
ALTER TABLE `responsable_prestation`
  ADD KEY `id` (`id`);

--
-- Index pour la table `secretaire`
--
ALTER TABLE `secretaire`
  ADD KEY `id` (`id`);

--
-- Index pour la table `specialisation`
--
ALTER TABLE `specialisation`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `antecedant`
--
ALTER TABLE `antecedant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `consultation`
--
ALTER TABLE `consultation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `detail_antecedant`
--
ALTER TABLE `detail_antecedant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `detail_ordonnace`
--
ALTER TABLE `detail_ordonnace`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `detail_prestation`
--
ALTER TABLE `detail_prestation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `detail_specialisation`
--
ALTER TABLE `detail_specialisation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT pour la table `ordonnance`
--
ALTER TABLE `ordonnance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `prestation`
--
ALTER TABLE `prestation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `rendez_vous`
--
ALTER TABLE `rendez_vous`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `specialisation`
--
ALTER TABLE `specialisation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
